import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/authRoutes.js";
import studentRoutes from "./routes/studentRoutes.js";
import feeRoutes from "./routes/feeRoutes.js";
import hostelRoutes from "./routes/hostelRoutes.js";
import examRoutes from "./routes/examRoutes.js";

dotenv.config();
const app = express();

const corsOptions = {
  origin: "https://5173-firebase-erp-1756555202984.cluster-iktsryn7xnhpexlu6255bftka4.cloudworkstations.dev", // Your frontend origin
  credentials: true, // Allow cookies and authentication headers
};

app.use(cors(corsOptions));  // Use configured CORS middleware
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/fees", feeRoutes);
app.use("/api/hostel", hostelRoutes);
app.use("/api/exams", examRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
